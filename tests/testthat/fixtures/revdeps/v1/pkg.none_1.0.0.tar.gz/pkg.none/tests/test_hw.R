path <- find.package("pkg.suggests", quiet = TRUE)
if (length(path) > 0) stop("Reverse suggested deps detected")
  
  
